# Matriz de Obligaciones Fiscales por Régimen

---

## Cuándo presenta qué — Resumen rápido

| Obligación | RESICO 626 | Sueldos 605 | Empresarial 612 | Arrendamiento 606 | PM |
|---|---|---|---|---|---|
| ISR mensual | ✅ Día 17 | ❌ (patrón retiene) | ✅ Día 17 | ✅ Día 17 (o trim.) | ✅ Día 17 |
| IVA mensual | ✅ Día 17 | ❌ | ✅ Día 17 | ✅ Día 17 (local) | ✅ Día 17 |
| Declaración anual | ⚠️ Opcional | ⚠️ Solo si >$400K | ✅ Obligatoria (Abr) | ✅ Obligatoria (Abr) | ✅ Obligatoria (Mar) |
| DIOT | ⚠️ Si >$4M | ❌ | ✅ Mensual | ⚠️ Si >$4M | ✅ Mensual |
| Contabilidad electrónica | ❌ | ❌ | ✅ | ❌ (opcional) | ✅ |
| CFDI por ingresos | ✅ | Recibir nómina | ✅ | ✅ con cuenta predial | ✅ |
| Nómina IMSS si hay empleados | ✅ | N/A | ✅ | ✅ | ✅ |

---

## RESICO 626 — Detalle completo

### Obligaciones mensuales (día 17 del mes siguiente)

| Formulario | Descripción | Observaciones |
|---|---|---|
| ISR provisional | Pago sobre ingresos cobrados del mes | Tasa 1%-2.4% según tabla Art. 113-E |
| IVA | Declaración definitiva | Nopal y alimentos básicos: tasa 0%. Servicios: 16% |

### Obligaciones por operación

| Obligación | Detalle |
|---|---|
| CFDI 4.0 | Por cada venta o servicio. RFC del receptor obligatorio (XAXX010101000 para público general) |
| CFDI global | Permitido: un CFDI diario que agrupa ventas al público en general en efectivo |

### Obligaciones anuales

| Obligación | Fecha | Notas |
|---|---|---|
| Declaración anual ISR | Abril | **Opcional** si todos los pagos mensuales están al corriente |
| Renovar e.firma si vence | Antes del vencimiento | En módulo SAT con cita |

### Obligaciones eventuales

| Obligación | Cuándo | Base |
|---|---|---|
| Actualizar RFC | Cambio de domicilio, actividades o cese | Art. 27 CFF · 10 días hábiles |
| Alta empleados IMSS | Al contratar el primer trabajador | Art. 15 LSS |
| DIOT | Solo si ingresos del año anterior > $4,000,000 | Art. 32 Fr. VIII LIVA |

---

## Sueldos y Salarios 605 — Detalle

### Obligaciones del trabajador

| Obligación | Condición |
|---|---|
| Proporcionar RFC al patrón | Siempre |
| Declaración anual (abril) | Si: ingresos >$400K; dos o más patrones; dejó de laborar antes del 31-dic; otros ingresos; ingresos del extranjero |
| Recibir y conservar CFDI nómina | Siempre |

### Exento de declarar anual si:
- Un solo patrón que emitió CFDI nómina por la totalidad
- Ingresos por salarios + intereses nominales ≤ $20,000

---

## Actividades Empresariales y Profesionales 612 — Detalle

### Obligaciones mensuales

| Formulario | Fecha | Detalle |
|---|---|---|
| ISR provisional | Día 17 | Ingresos − Deducciones × Tarifa Art. 152 LISR |
| IVA | Día 17 | 16% general; 0% alimentos; exentos según LIVA |
| DIOT | Día 17 | Declaración Informativa Operaciones con Terceros |

### Obligaciones anuales

| Obligación | Fecha |
|---|---|
| Declaración anual ISR | Abril — **OBLIGATORIA** |
| Envío contabilidad electrónica | Mensual vía buzón tributario |

### Deducciones operativas autorizadas (Art. 27 LISR)

Gastos estrictamente indispensables pagados con CFDI y medios electrónicos:
- Mercancías, materias primas, insumos directos
- Arrendamiento de oficinas y locales
- Salarios y cuotas patronales IMSS
- Servicios (agua, luz, teléfono, internet)
- Combustible y transportes
- Publicidad y marketing
- Honorarios profesionales externos

---

## Arrendamiento 606 — Detalle

### Opciones de deducción (excluyentes)

**Opción 1 — Deducción comprobada**:
- Impuesto predial del año en curso
- Gastos de mantenimiento (comprobados con CFDI)
- Primas de seguro del inmueble
- Intereses reales de crédito hipotecario sobre el inmueble

**Opción 2 — Deducción "ciega"** (sin comprobantes):
- 35% de los ingresos brutos
- + Impuesto predial pagado completo

### CFDI de arrendamiento

Debe incluir obligatoriamente:
- Número de cuenta predial del inmueble
- Descripción clara del tipo de inmueble
- Periodo de arrendamiento

---

## Nómina — Obligaciones del patrón (cualquier régimen)

### Al contratar el primer trabajador

1. Inscribir a la empresa como patrón ante el IMSS (portal IMSS Digital)
2. Dar de alta a cada trabajador con: RFC, CURP, NSS (Número de Seguridad Social)
3. Registrarse ante el INFONAVIT
4. Obtener registro patronal (número de 11 caracteres)

### Obligaciones periódicas de nómina

| Obligación | Periodicidad | Fecha límite |
|---|---|---|
| Pago de nómina + CFDI nómina | Semanal/quincenal/mensual | Según contrato |
| Retención ISR trabajador | Con cada pago | Enterar día 17 del mes siguiente |
| Cuotas IMSS (patrón + trabajador) | Bimestral | Día 17 del mes siguiente al bimestre |
| Aportación INFONAVIT (5%) | Bimestral | Día 17 del mes siguiente al bimestre |
| Aportación SAR (2%) | Bimestral | Con INFONAVIT |

### Prestaciones mínimas de ley (LFT)

| Prestación | Cálculo | Base |
|---|---|---|
| Aguinaldo | 15 días de salario por año | Art. 87 LFT · Pagar antes 20-dic |
| Vacaciones (1er año) | 12 días | Art. 76 LFT |
| Prima vacacional | 25% sobre días de vacaciones | Art. 80 LFT |
| PTU | 10% de utilidades de la empresa | Art. 117-131 LFT · Mayo |
| IMSS | Inscripción y cuotas | Art. 15 LSS |

### Finiquito vs Liquidación

| Concepto | Aplica en | Componentes |
|---|---|---|
| **Finiquito** | Renuncia voluntaria | Vacaciones no gozadas + Prima vacacional + Aguinaldo proporcional + Parte proporcional PTU |
| **Liquidación** | Despido injustificado | Todo el finiquito + 3 meses de salario + 20 días por año trabajado + Prima antigüedad (12 días por año) |
