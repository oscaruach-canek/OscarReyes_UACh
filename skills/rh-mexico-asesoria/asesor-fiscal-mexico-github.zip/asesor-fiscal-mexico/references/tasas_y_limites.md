# Tasas, Límites y Referencias Numéricas — México 2024-2026

---

## UMA (Unidad de Medida y Actualización)

| Periodo | Valor diario | Valor mensual | Valor anual |
|---|---|---|---|
| 2024 | $108.57 | $3,300.53 | $39,606.36 |
| 2025 | $113.14 | $3,440.93 | $41,291.16 |

---

## Salario Mínimo General

| Año | Diario (zona general) | Diario (zona fronteriza norte) |
|---|---|---|
| 2024 | $248.93 MXN | $374.89 MXN |
| 2025 | $278.80 MXN | $419.88 MXN |

---

## Tasas ISR RESICO Personas Físicas (Art. 113-E LISR)

### Tabla mensual vigente

| Rango de ingreso mensual | Tasa ISR |
|---|---|
| $0.01 — $25,000 | 1.00% |
| $25,000.01 — $50,000 | 1.10% |
| $50,000.01 — $83,333.33 | 1.50% |
| $83,333.34 — $208,333.33 | 2.00% |
| $208,333.34 — $291,666.67 | 2.40% |

**Nota**: Tasas aplicadas sobre el ingreso total del rango (no marginal).

### Equivalencia anual de límites RESICO

| Límite mensual | Límite anual equivalente |
|---|---|
| $25,000 | $300,000 |
| $50,000 | $600,000 |
| $83,333 | $1,000,000 |
| $208,333 | $2,500,000 |
| $291,666 | $3,500,000 ← límite máximo RESICO |

---

## Tarifas ISR Personas Físicas (Art. 96 y 152 LISR) — Régimen General

### Tarifa mensual para retención de sueldos y pagos provisionales

| Límite inferior | Límite superior | Cuota fija | Tasa sobre excedente |
|---|---|---|---|
| $0.01 | $746.04 | $0.00 | 1.92% |
| $746.05 | $6,332.05 | $14.32 | 6.40% |
| $6,332.06 | $11,128.01 | $371.83 | 10.88% |
| $11,128.02 | $12,935.82 | $893.63 | 16.00% |
| $12,935.83 | $15,487.71 | $1,182.88 | 17.92% |
| $15,487.72 | $31,236.49 | $1,640.18 | 21.36% |
| $31,236.50 | $49,233.00 | $5,004.12 | 23.52% |
| $49,233.01 | $93,993.90 | $9,236.89 | 30.00% |
| $93,993.91 | $125,325.20 | $22,665.17 | 32.00% |
| $125,325.21 | $375,975.61 | $32,691.18 | 34.00% |
| $375,975.62 | En adelante | $117,912.32 | 35.00% |

---

## Tasas IVA (LIVA)

| Concepto | Tasa |
|---|---|
| General (servicios, bienes no básicos) | 16% |
| Zona fronteriza norte | 8% |
| Alimentos en estado natural (nopal, verduras, frutas) | **0%** |
| Medicamentos | 0% |
| Libros y revistas | 0% |
| Exportaciones | 0% |
| Casa habitación (arrendamiento) | Exento |
| Fincas agrícolas y ganaderas (arrendamiento) | Exento |

---

## Límites y umbrales clave

| Concepto | Monto | Base legal |
|---|---|---|
| Límite RESICO | $3,500,000/año | Art. 113-E LISR |
| Límite RIF | $2,000,000/año | Art. 111 LISR (extinción) |
| Máx. deducción personal global | MIN(5 UMA anual, 15% ingresos) | Art. 151 LISR |
| Lentes ópticos deducibles | $2,500 MXN | Art. 151 LISR |
| Crédito hipotecario deducible | ≤750,000 UDIS | Art. 151 LISR |
| Límite pago en efectivo deducible | $2,000 por operación | Art. 27 Fr. III LISR |
| Obligación declarar anual (sueldos) | >$400,000/año | Art. 98 LISR |
| Relevación DIOT arrendamiento | Ingresos previos ≤$4,000,000 | Art. 32 Fr. VIII LIVA |
| ISR PM | 30% sobre utilidad | Art. 9 LISR |
| ISR dividendos PM | 10% adicional | Art. 140 LISR |
| Plataformas: pagos definitivos | ≤$300,000/año | Art. 113-A LISR |

---

## Cuotas IMSS (referencia para nómina)

### Cuotas patronales estimadas (sobre SBC — Salario Base de Cotización)

| Ramo | Tasa patronal aprox. |
|---|---|
| Enfermedades y maternidad (cuota fija) | Por trabajador/día |
| Enfermedades y maternidad (excedente) | 1.10% sobre SBC > 3 SM |
| Invalidez y vida | 1.75% |
| Retiro (SAR) | 2.00% |
| Cesantía y vejez | 3.150% |
| Guarderías y prestaciones sociales | 1.00% |
| Riesgos de trabajo | 0.50% a 7.58% según prima |
| INFONAVIT | 5.00% |
| **Total aprox. patronal** | **~30-35% sobre SBC** |

### Cuotas trabajador

| Ramo | Tasa trabajador |
|---|---|
| Enfermedades y maternidad | 0.40% sobre SBC > 3 SM |
| Invalidez y vida | 0.625% |
| Cesantía y vejez | 1.125% |
| **Total aprox. trabajador** | **~2.15% sobre SBC** |

---

## Fechas de declaración

| Obligación | Fecha límite |
|---|---|
| Declaración anual PF | **Abril** del año siguiente |
| Declaración anual PM | **Marzo** del año siguiente |
| Pagos provisionales ISR/IVA | **Día 17** del mes siguiente |
| Declaración trimestral (si aplica) | **Día 17** del mes siguiente al trimestre |
| DIOT mensual | **Día 17** del mes siguiente |
| Cuotas IMSS (bimestral) | **Día 17** del mes siguiente al bimestre |
| Actualización RFC | **10 días hábiles** tras el cambio |

---

## Multas y sanciones frecuentes (CFF y LSS)

| Infracción | Multa aproximada |
|---|---|
| No presentar declaración en tiempo | $1,400 a $17,370 (Art. 82 CFF) |
| No expedir CFDI | $17,020 a $97,330 por operación (Art. 84 CFF) |
| No inscribirse al RFC | $3,500 a $10,570 (Art. 79 CFF) |
| Trabajador no inscrito IMSS | $595 a $2,380 por trabajador (Art. 304-A LSS) |
| Omisión de ingresos | 55% a 75% del impuesto omitido (Art. 76 CFF) |
| Defraudación fiscal | Prisión de 3 meses a 9 años (Art. 108 CFF) |
