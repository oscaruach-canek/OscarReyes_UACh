# Deducciones Personales — Art. 151 LISR

> Aplican SOLO en Declaración Anual. NO disponibles en RESICO para ISR.

---

## Límite global (Art. 151 último párrafo LISR)

```
Tope = MIN(5 UMA anuales, 15% de ingresos brutos totales incluyendo exentos)
```

| Referencia | Monto 2024 |
|---|---|
| UMA diaria 2024 | $108.57 MXN |
| UMA mensual 2024 | $3,300.53 MXN |
| UMA anual 2024 | $39,606.36 MXN |
| **5 UMA anuales** | **$198,031.80 MXN** |

**Excluidos del tope global**: Donativos deducibles y estímulos fiscales por colegiaturas.

**Regla de pago**: Todos los gastos deben pagarse con tarjeta de débito, crédito, cheque nominativo o transferencia electrónica. El pago en efectivo inhabilita la deducción.

---

## Conceptos deducibles

### 1. Salud

| Concepto | Requisitos | Límite |
|---|---|---|
| Honorarios médicos y dentales | CFDI del profesional | General (sujeto al tope global) |
| Servicios de psicología y nutrición | CFDI del profesional | General |
| Gastos hospitalarios | CFDI del hospital | General |
| Medicamentos | Solo los facturados por hospitales | General |
| Análisis clínicos | CFDI del laboratorio | General |
| Prótesis | CFDI | General |
| Lentes ópticos graduados | CFDI | **$2,500 MXN máximo** |
| Primas de seguros médicos | CFDI de aseguradora | General |

**Nota**: Aplica para el contribuyente, cónyuge o concubino/a, ascendientes y descendientes en línea recta.

### 2. Educación (Colegiaturas)

Solo instituciones con validez oficial de estudios (RVOE). **No aplica** inscripción ni útiles.

| Nivel educativo | Límite anual por alumno |
|---|---|
| Preescolar | $14,200 MXN |
| Primaria | $12,900 MXN |
| Secundaria | $19,900 MXN |
| Profesional técnico | $17,100 MXN |
| Bachillerato | $24,500 MXN |

Aplica para el contribuyente, cónyuge o concubino/a, y ascendientes o descendientes en línea recta.

### 3. Gastos funerarios

| Concepto | Límite |
|---|---|
| Funerales de cónyuge, padres, abuelos, hijos, nietos | 1 UMA anual ($39,606.36 MXN) |

Comprobación: CFDI de la funeraria autorizada.

### 4. Créditos hipotecarios

| Concepto | Requisitos |
|---|---|
| Intereses reales pagados | Solo casa habitación del contribuyente |
| Instituciones autorizadas | INFONAVIT, FOVISSSTE, bancos |
| Límite del crédito | Monto original ≤ 750,000 UDIS |

**Interés real** = Interés nominal − Ajuste por inflación anual.

### 5. Aportaciones voluntarias a retiro

- Aportaciones voluntarias a AFORE o planes personales de retiro
- Límite: 10% de los ingresos acumulables del ejercicio, con máximo de 5 UMA anuales ($198,031.80)

### 6. Donativos

- A instituciones autorizadas por el SAT (Donatarias Autorizadas)
- Límite: 7% de los ingresos acumulables del ejercicio anterior
- **Excluido del tope global** del Art. 151

### 7. Impuesto local por salarios

- Cuotas pagadas al IMSS por el trabajador
- Primas de seguros contra riesgos profesionales
- Límite: No aplica tope específico, sujeto al tope global

---

## Resumen rápido: ¿quién puede deducir qué?

| Régimen | Deducciones personales | Deducciones operativas |
|---|---|---|
| RESICO (626) | **NO** (Art. 113-E LISR) | Solo para IVA acreditable |
| Sueldos (605) | **SÍ** en declaración anual | No aplica |
| Empresarial (612) | **SÍ** en declaración anual | Gastos indispensables con CFDI |
| Arrendamiento (606) | **SÍ** en declaración anual | Gastos del inmueble o 35% ciego |

---

## Checklist de requisitos formales

- [ ] CFDI vigente con RFC del contribuyente
- [ ] Pago realizado con medio electrónico (no efectivo)
- [ ] Gasto en el ejercicio fiscal a declarar
- [ ] Relación con el contribuyente, cónyuge o dependientes
- [ ] Para educación: institución con RVOE vigente
- [ ] Para hipoteca: constancia de intereses del banco/INFONAVIT/FOVISSSTE
