# Regímenes Fiscales Personas Físicas — México

> Fuente base: SAT México · LISR vigente · Actualizado mayo 2026

---

## 1. RESICO — Régimen Simplificado de Confianza (Código 626)

**Art. 113-E al 113-J LISR**

| Campo | Detalle |
|---|---|
| Perfil | Profesionales independientes, emprendedores, arrendadores, sector agropecuario |
| Límite de ingresos | $3,500,000 MXN anuales (migración automática al superarlo) |
| Base gravable ISR | Ingreso bruto cobrado (sin deducciones) |
| Tasa ISR | Escalonada 1.00% a 2.50% (ver tabla de tasas) |
| IVA | Declaración mensual obligatoria; deducciones válidas para IVA acreditable |
| Declaración anual | Opcional (relevado si pagos mensuales al corriente) |
| Deducciones personales | **NO aplican** para ISR |
| Contabilidad electrónica | No obligatoria |
| DIOT | Solo si ingresos previos > $4,000,000 |

### Tabla de tasas RESICO 2024 (Art. 113-E LISR)

| Ingreso mensual hasta | Tasa ISR |
|---|---|
| $25,000 | 1.00% |
| $50,000 | 1.10% |
| $83,333 | 1.50% |
| $208,333 | 2.00% |
| $291,666 | 2.40% |

### Actividades incluidas en RESICO

- Actividades empresariales (comercio, industria, autotransporte)
- Honorarios profesionales (médicos, abogados, ingenieros, diseñadores)
- Arrendamiento de bienes inmuebles
- Actividades agrícolas, ganaderas, silvícolas y pesqueras ← **Aplica para nopal**

### Obligaciones RESICO

1. RFC con e.firma vigente y buzón tributario activo
2. Emitir CFDI por cada operación (o CFDI global diario)
3. Pago provisional ISR mensual → día 17 del mes siguiente
4. Declaración IVA mensual → día 17 del mes siguiente
5. Conservar comprobantes 5 años mínimo (Art. 30 CFF)
6. Actualizar RFC ante cambios (Art. 27 CFF)

---

## 2. Sueldos y Salarios e Ingresos Asimilados (Código 605)

**Art. 94-99 LISR**

| Campo | Detalle |
|---|---|
| Perfil | Empleados con relación laboral subordinada |
| Límite ingresos | Sin límite |
| Retención ISR | A cargo del patrón (el trabajador no declara mensualmente) |
| Declaración anual | Obligatoria si: ingresos > $400,000, dos o más patrones simultáneos, dejó de laborar antes del 31-dic, otros ingresos acumulables |
| Exento de declarar anual | Solo un patrón que emitió CFDI nómina por la totalidad + ingresos salarios + intereses ≤ $20,000 |
| Deducciones personales | **SÍ aplican** en declaración anual |

---

## 3. Actividades Empresariales y Profesionales — Régimen General (Código 612)

**Art. 100-110 LISR**

| Campo | Detalle |
|---|---|
| Perfil | Comerciantes, industriales, profesionistas con honorarios |
| Límite ingresos | Sin límite |
| Base gravable ISR | Ingresos − Deducciones autorizadas (gastos indispensables con CFDI) |
| Tasa ISR | Tarifa progresiva Art. 152 LISR (hasta 35%) |
| Declaración anual | **OBLIGATORIA** (abril) |
| Declaraciones mensuales | ISR e IVA → día 17 del mes siguiente |
| DIOT | Mensual obligatorio |
| Contabilidad electrónica | **OBLIGATORIA** |
| Deducciones personales | **SÍ aplican** |
| Deducciones operativas | Gastos estrictamente indispensables con CFDI (Art. 27 LISR) |

---

## 4. Arrendamiento (Código 606)

**Art. 114-118 LISR**

| Campo | Detalle |
|---|---|
| Perfil | Arrendadores de bienes inmuebles (casa, local, bodega, terreno) |
| Límite ingresos | Sin límite |
| IVA casa habitación | Exento |
| IVA local comercial | 16% |
| Declaraciones provisionales | Mensual (o trimestral si ingresos mensuales ≤ $26,411.52) |
| Declaración anual | Obligatoria (abril) |
| DIOT | Relevado si ingresos año anterior ≤ $4,000,000 |
| Deducciones | **Opción 1**: Gastos comprobados (predial, mantenimiento, seguros, intereses hipotecarios reales) |
| | **Opción 2 "Ciega"**: 35% de ingresos brutos + predial completo (sin comprobantes) |

---

## 5. Régimen de Incorporación Fiscal — RIF (en extinción)

| Campo | Detalle |
|---|---|
| Perfil | Pequeños contribuyentes (tianguistas, taxistas, carpinteros, tiendas de abarrotes) |
| Límite ingresos | $2,000,000 MXN anuales |
| Estado | **En proceso de desaparición** — no recomendable para nuevos contribuyentes |
| Declaración anual | No obligatoria (excepto opción coeficiente de utilidad) |

---

## 6. Persona Moral — Régimen General

**Art. 9 LISR**

| Campo | Detalle |
|---|---|
| Formas jurídicas | SA de CV, S de RL, SAS (Sociedad por Acciones Simplificada) |
| Tasa ISR | **30% sobre utilidad fiscal** |
| Base gravable | Ingresos acumulables − Deducciones autorizadas |
| Declaraciones provisionales | Mensuales (Art. 14 LISR) |
| Declaración anual | Marzo del año siguiente |
| Contabilidad | Obligatoria y electrónica |
| DIOT | Mensual |
| Dividendos | ISR adicional 10% al distribuir |

### Cuándo conviene PM vs PF

| Conviene PM | Conviene PF |
|---|---|
| Ingresos > $3.5M anuales | Ingresos ≤ $3.5M en RESICO |
| Varios socios | Operación unipersonal |
| Necesidad de crédito bancario | Sin necesidad de financiamiento formal |
| Ventas B2B con grandes empresas | Ventas B2C o mercado local |
| Protección patrimonial crítica | Activos personales no en riesgo |
| Gastos 100% documentados | Muchas operaciones en efectivo |

---

## Tabla comparativa general

| Régimen | Código | Límite anual | Tasa ISR | Dec. Anual | Ded. Personales | Contabilidad |
|---|---|---|---|---|---|---|
| RESICO | 626 | $3,500,000 | 1%-2.5% | Opcional | NO | No |
| Sueldos/Salarios | 605 | Sin límite | Tarifa | Si >$400K | SÍ | No |
| Empresarial/Prof. | 612 | Sin límite | Tarifa (≤35%) | OBLIGATORIA | SÍ | Sí |
| RIF | — | $2,000,000 | Reducida | No | SÍ | Simplificada |
| Arrendamiento | 606 | Sin límite (DIOT >$4M) | Tarifa | OBLIGATORIA | SÍ | Opcional |
| Persona Moral | — | Sin límite | 30% utilidad | OBLIGATORIA | N/A | Sí |
