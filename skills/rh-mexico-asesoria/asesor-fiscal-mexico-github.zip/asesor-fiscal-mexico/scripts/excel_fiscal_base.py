"""
excel_fiscal_base.py
Funciones helper reutilizables para construir archivos Excel fiscales profesionales.
Uso: from excel_fiscal_base import *
"""
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ── PALETA DE COLORES ─────────────────────────────────────────────────────────
C_GREEN_DARK  = "1D6A35"
C_GREEN_MED   = "2E8B4A"
C_GREEN_LIGHT = "D6EEDD"
C_GREEN_PALE  = "F0F7F2"
C_AMBER       = "F5A623"
C_AMBER_LIGHT = "FFF3DC"
C_RED         = "C0392B"
C_RED_LIGHT   = "FDECEA"
C_BLUE        = "1A5276"
C_BLUE_LIGHT  = "D6EAF8"
C_GRAY_DARK   = "4A4A4A"
C_GRAY_MED    = "7F8C8D"
C_GRAY_LIGHT  = "F2F2F2"
C_WHITE       = "FFFFFF"
C_BORDER      = "BDBDBD"

# ── FUNCIONES BASE ────────────────────────────────────────────────────────────
def fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)

def font(bold=False, color="000000", size=10, italic=False, name="Arial"):
    return Font(bold=bold, color=color, size=size, italic=italic, name=name)

def border_thin():
    s = Side(style='thin', color=C_BORDER)
    return Border(left=s, right=s, top=s, bottom=s)

def border_medium():
    s = Side(style='medium', color=C_GREEN_DARK)
    return Border(left=s, right=s, top=s, bottom=s)

def align(h="left", v="center", wrap=False):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)

def money_fmt():
    return '"$"#,##0.00;("$"#,##0.00);"-"'

def pct_fmt():
    return '0.0%'

def style_cell(ws, cell_ref, bold=False, fg=None, font_color="000000",
               size=10, h_align="left", wrap=False, italic=False,
               border=True, number_format=None):
    """Aplica estilo completo a una celda."""
    c = ws[cell_ref]
    c.font = font(bold=bold, color=font_color, size=size, italic=italic)
    if fg:
        c.fill = fill(fg)
    c.alignment = align(h_align, wrap=wrap)
    if border:
        c.border = border_thin()
    if number_format:
        c.number_format = number_format
    return c

# ── BLOQUES REUTILIZABLES ─────────────────────────────────────────────────────
def build_header_block(ws, negocio: str, regimen: str, start_row=1):
    """
    Construye el bloque de encabezado estándar.
    Requiere columnas B-F disponibles. Retorna la siguiente fila disponible.
    
    Args:
        ws: worksheet de openpyxl
        negocio: ej. "Producción y Comercialización de Nopal"
        regimen: ej. "RESICO — Régimen Simplificado de Confianza (626) · Persona Física"
        start_row: fila donde inicia el bloque
    """
    r = start_row
    ws.merge_cells(f'B{r}:F{r}')
    ws[f'B{r}'] = "PROPUESTA FISCAL Y DE DEDUCCIONES"
    ws[f'B{r}'].font = Font(bold=True, color=C_WHITE, size=16, name="Arial")
    ws[f'B{r}'].fill = fill(C_GREEN_DARK)
    ws[f'B{r}'].alignment = align("center")
    ws.row_dimensions[r].height = 28

    ws.merge_cells(f'B{r+1}:F{r+1}')
    ws[f'B{r+1}'] = f"Negocio: {negocio}"
    ws[f'B{r+1}'].font = Font(color=C_WHITE, size=11, name="Arial")
    ws[f'B{r+1}'].fill = fill(C_GREEN_MED)
    ws[f'B{r+1}'].alignment = align("center")
    ws.row_dimensions[r+1].height = 22

    ws.merge_cells(f'B{r+2}:F{r+2}')
    ws[f'B{r+2}'] = f"Régimen: {regimen}"
    ws[f'B{r+2}'].font = Font(color=C_GREEN_DARK, size=10, italic=True, name="Arial")
    ws[f'B{r+2}'].fill = fill(C_GREEN_LIGHT)
    ws[f'B{r+2}'].alignment = align("center")
    ws.row_dimensions[r+2].height = 18

    return r + 3

def build_kpi_row(ws, kpis: list, start_row: int, start_col: str = 'C'):
    """
    Construye una fila de KPI cards.
    
    Args:
        kpis: lista de dicts con keys 'label', 'value', 'sub', 'format' (money/pct/text)
        start_row: fila donde inicia la etiqueta
        start_col: columna inicial (por defecto 'C')
    
    Ejemplo:
        kpis = [
            {'label': 'Ingreso semanal', 'value': 45000, 'sub': 'MXN', 'format': 'money'},
            {'label': 'Tasa ISR', 'value': 0.024, 'sub': 'RESICO', 'format': 'pct'},
        ]
    """
    col_idx = ord(start_col) - ord('A') + 1
    for i, kpi in enumerate(kpis):
        col = get_column_letter(col_idx + i)
        label_cell = f'{col}{start_row}'
        val_cell   = f'{col}{start_row+1}'
        sub_cell   = f'{col}{start_row+2}'

        ws[label_cell] = kpi['label']
        ws[label_cell].font = Font(size=9, color=C_GRAY_MED, name="Arial")
        ws[label_cell].fill = fill(C_GREEN_PALE)
        ws[label_cell].alignment = align("center")
        ws[label_cell].border = border_thin()

        ws[val_cell] = kpi['value']
        ws[val_cell].font = Font(bold=True, size=14, color=C_GREEN_DARK, name="Arial")
        ws[val_cell].fill = fill(C_GREEN_PALE)
        ws[val_cell].alignment = align("center")
        ws[val_cell].border = border_thin()
        ws.row_dimensions[start_row+1].height = 32

        if kpi.get('format') == 'money':
            ws[val_cell].number_format = money_fmt()
        elif kpi.get('format') == 'pct':
            ws[val_cell].number_format = pct_fmt()

        ws[sub_cell] = kpi.get('sub', '')
        ws[sub_cell].font = Font(size=8, color=C_GRAY_MED, italic=True, name="Arial")
        ws[sub_cell].fill = fill(C_GREEN_PALE)
        ws[sub_cell].alignment = align("center")
        ws[sub_cell].border = border_thin()

    return start_row + 3

def build_alert_row(ws, mensaje: str, row: int, tipo='warning'):
    """
    Inserta una fila de alerta (warning, danger, info).
    
    Args:
        tipo: 'warning' (ámbar), 'danger' (rojo), 'info' (azul)
    """
    colores = {
        'warning': (C_AMBER_LIGHT, C_AMBER),
        'danger':  (C_RED_LIGHT, C_RED),
        'info':    (C_BLUE_LIGHT, C_BLUE),
    }
    bg, fg = colores.get(tipo, (C_AMBER_LIGHT, C_AMBER))
    ws.merge_cells(f'B{row}:F{row}')
    ws[f'B{row}'] = mensaje
    ws[f'B{row}'].font = Font(bold=True, size=9, color=fg, name="Arial")
    ws[f'B{row}'].fill = fill(bg)
    ws[f'B{row}'].alignment = align("center", wrap=True)
    ws[f'B{row}'].border = border_thin()
    ws.row_dimensions[row].height = 28
    return row + 1

def build_section_header(ws, titulo: str, row: int):
    """Inserta un sub-encabezado de sección."""
    ws.merge_cells(f'B{row}:F{row}')
    ws[f'B{row}'] = titulo
    ws[f'B{row}'].font = Font(bold=True, size=10, color=C_WHITE, name="Arial")
    ws[f'B{row}'].fill = fill(C_GREEN_DARK)
    ws[f'B{row}'].alignment = align("center")
    ws[f'B{row}'].border = border_thin()
    ws.row_dimensions[row].height = 16
    return row + 1

def build_table_headers(ws, headers: list, row: int, start_col='B', bg=C_GREEN_MED):
    """Construye una fila de encabezados de tabla."""
    for i, h in enumerate(headers):
        col = get_column_letter(ord(start_col) - ord('A') + 1 + i)
        ws[f'{col}{row}'] = h
        ws[f'{col}{row}'].font = Font(bold=True, size=9, color=C_WHITE, name="Arial")
        ws[f'{col}{row}'].fill = fill(bg)
        ws[f'{col}{row}'].alignment = align("center")
        ws[f'{col}{row}'].border = border_thin()
    ws.row_dimensions[row].height = 16
    return row + 1

def build_data_row(ws, data: list, row: int, start_col='B',
                   alternating=True, bold_first=True):
    """
    Inserta una fila de datos con formato alternado.
    
    Args:
        data: lista de valores (str, int, float, o formula str comenzando con '=')
        alternating: True = color alternado par/impar
    """
    bg = C_WHITE if (row % 2 == 0) else C_GREEN_PALE if alternating else C_WHITE
    for i, val in enumerate(data):
        col = get_column_letter(ord(start_col) - ord('A') + 1 + i)
        ws[f'{col}{row}'] = val
        ws[f'{col}{row}'].fill = fill(bg)
        ws[f'{col}{row}'].font = Font(
            size=9, color=C_GRAY_DARK, name="Arial",
            bold=(bold_first and i == 0)
        )
        ws[f'{col}{row}'].alignment = align("left" if i == 0 else "center")
        ws[f'{col}{row}'].border = border_thin()
    ws.row_dimensions[row].height = 16
    return row + 1

def build_total_row(ws, formulas: dict, row: int, label: str, start_col='B',
                    n_cols=5):
    """
    Construye la fila de totales con fondo verde oscuro.
    
    Args:
        formulas: dict col_letter → formula string, ej. {'C': '=SUM(C14:C21)'}
        label: texto de la primera columna
    """
    ws[f'B{row}'] = label
    ws[f'B{row}'].font = Font(bold=True, size=10, color=C_WHITE, name="Arial")
    ws[f'B{row}'].fill = fill(C_GREEN_DARK)
    ws[f'B{row}'].alignment = align("left")
    ws[f'B{row}'].border = border_thin()

    col_idx = ord(start_col) - ord('A') + 2
    for i in range(n_cols - 1):
        col = get_column_letter(col_idx + i)
        formula = formulas.get(col, "")
        ws[f'{col}{row}'] = formula
        ws[f'{col}{row}'].font = Font(bold=True, size=10, color=C_WHITE, name="Arial")
        ws[f'{col}{row}'].fill = fill(C_GREEN_DARK)
        ws[f'{col}{row}'].alignment = align("center")
        ws[f'{col}{row}'].border = border_thin()
        if formula and formula.startswith('='):
            ws[f'{col}{row}'].number_format = money_fmt()
    ws.row_dimensions[row].height = 20
    return row + 1

def build_legal_note(ws, row: int):
    """Inserta la nota de deslinde legal estándar."""
    nota = ("Nota legal: Esta información es orientativa. No sustituye el análisis personalizado "
            "con un contador público inscrito ante el SAT. Base: LISR, LIVA, CFF y RMF vigentes. "
            "Fuentes: wwwmat.sat.gob.mx/personas · diputados.gob.mx/LeyesBiblio/")
    ws.merge_cells(f'B{row}:F{row}')
    ws[f'B{row}'] = nota
    ws[f'B{row}'].font = Font(italic=True, size=8, color=C_GRAY_MED, name="Arial")
    ws[f'B{row}'].fill = fill(C_GRAY_LIGHT)
    ws[f'B{row}'].alignment = align("center", wrap=True)
    ws[f'B{row}'].border = border_thin()
    ws.row_dimensions[row].height = 28
    return row + 1

def setup_sheet(ws, col_widths: dict, hide_gridlines=True):
    """
    Configura el worksheet con anchos de columna y oculta cuadrícula.
    
    Args:
        col_widths: dict col_letter → ancho, ej. {'A': 2, 'B': 30, 'C': 18}
    """
    ws.sheet_view.showGridLines = not hide_gridlines
    for col, width in col_widths.items():
        ws.column_dimensions[col].width = width

# ── HOJAS ESTÁNDAR ────────────────────────────────────────────────────────────
OBLIGACIONES_RESICO = [
    ("Pago provisional ISR",      "Mensual",       "Día 17 mes siguiente", "Art. 113-E LISR", "Tasa 1%-2.4% ingresos cobrados"),
    ("Declaración IVA",            "Mensual",       "Día 17 mes siguiente", "Art. 5-E LIVA",   "Nopal fresco: tasa 0%"),
    ("Emisión de CFDI",            "Por operación", "Al vender",            "Art. 29 CFF",     "CFDI 4.0 · Global diario válido"),
    ("Retención ISR nómina",       "Quincenal",     "Quincena siguiente",   "Art. 96 LISR",    "Si tienes empleados"),
    ("Cuotas IMSS patronal",       "Bimestral",     "Día 17 mes siguiente", "Art. 39 LSS",     "Todos los trabajadores inscritos"),
    ("Declaración anual ISR",      "Anual",         "Abril del año sig.",   "Art. 113-G LISR", "Opcional si pagos al corriente"),
    ("Actualización RFC",          "Cuando aplique","10 días hábiles",      "Art. 27 CFF",     "Cambio domicilio, actividades"),
    ("e.firma vigente",            "Cada 4 años",   "Antes de vencer",      "Art. 17-D CFF",   "Renovar en módulo SAT"),
    ("Conservar comprobantes",     "Permanente",    "Mínimo 5 años",        "Art. 30 CFF",     "CFDI ingresos y gastos"),
]

TASAS_RESICO = [
    (25_000,   0.0100),
    (50_000,   0.0110),
    (83_333,   0.0150),
    (208_333,  0.0200),
    (291_666,  0.0240),
]

def get_tasa_resico(ingreso_mensual: float) -> float:
    """Retorna la tasa RESICO aplicable para el ingreso mensual dado."""
    for limite, tasa in TASAS_RESICO:
        if ingreso_mensual <= limite:
            return tasa
    return 0.0240

# ── ESTACIONALIDAD POR SECTOR ─────────────────────────────────────────────────
# Multiplicadores mensuales [Ene-Dic] para ajustar deducciones según sector
ESTACIONALIDAD = {
    "agropecuario": {
        "insumos":       [1.3,1.3,1.0,0.9,0.9,0.8,0.8,1.0,1.2,1.2,1.0,0.9],
        "fertilizantes": [1.2,1.2,1.1,1.0,0.9,0.8,0.8,0.9,1.1,1.1,1.0,0.9],
        "agua":          [0.8,0.8,1.0,1.2,1.3,1.3,1.2,1.1,1.0,0.9,0.8,0.8],
        "combustible":   [1.0,1.0,1.0,1.0,1.0,1.1,1.1,1.0,1.0,1.0,1.0,0.8],
        "nomina":        [1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.5],  # aguinaldo dic
    },
    "comercio": {
        "inventario":    [0.8,0.9,1.0,1.0,1.0,1.0,1.1,1.1,1.0,1.0,1.2,1.5],
        "nomina":        [1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.5],
        "publicidad":    [0.7,0.8,0.8,0.9,1.0,1.0,1.2,1.2,1.0,1.0,1.5,1.9],
    },
    "servicios": {
        "papeleria":     [1.5,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,0.5],
        "nomina":        [1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.5],
        "capacitacion":  [1.5,0.8,0.8,1.0,1.0,0.8,1.5,0.8,1.0,1.0,0.8,0.6],
    },
}
