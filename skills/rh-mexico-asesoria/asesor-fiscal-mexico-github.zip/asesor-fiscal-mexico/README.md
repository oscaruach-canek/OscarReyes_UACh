# 🌿 Asesor Fiscal México — Skill para Claude

Skill especializada para Claude que actúa como **asesor contable experto en México**, generando análisis fiscales completos, dashboards HTML interactivos y archivos Excel (.xlsx) dinámicos basados en los documentos del SAT y la LISR vigente.

---

## ¿Qué hace esta skill?

| Capacidad | Descripción |
|---|---|
| 📊 **Dashboard interactivo** | KPIs fiscales, simuladores de ISR, barras de progreso de límites, calendarios fiscales |
| 📁 **Excel dinámico (.xlsx)** | 4 hojas: Resumen ejecutivo, Detalle mensual con estacionalidad, Calendario fiscal, Simulador ISR |
| ⚖️ **Comparativo PF vs PM** | Análisis de riesgo, ventajas/desventajas según perfil del negocio |
| 🧾 **Recomendación de régimen** | Árbol de decisión basado en ingresos, actividad, empleados y perfil operativo |
| 📚 **Base normativa** | Cita artículos LISR, LIVA, CFF y RMF en cada recomendación |

---

## Regímenes cubiertos

- **RESICO** — Régimen Simplificado de Confianza (Código 626) · Art. 113-E LISR
- **Sueldos y Salarios** (Código 605) · Art. 94-99 LISR
- **Actividades Empresariales y Profesionales** (Código 612) · Art. 100-110 LISR
- **Arrendamiento** (Código 606) · Art. 114-118 LISR
- **RIF** (en extinción)
- **Persona Moral** — Régimen General · Art. 9 LISR

---

## Estructura del repositorio

```
asesor-fiscal-mexico/
├── SKILL.md                          # Instrucciones principales para Claude
├── README.md                         # Este archivo
├── references/
│   ├── regimenes_fiscales.md         # Resumen completo de regímenes
│   ├── deducciones_personales.md     # Art. 151 LISR, topes y requisitos
│   ├── tasas_y_limites.md            # UMA, salario mínimo, tasas ISR/IVA
│   └── obligaciones_por_regimen.md  # Matriz de obligaciones
└── scripts/
    └── excel_fiscal_base.py          # Funciones helper para Excel (.xlsx)
```

---

## Instalación

### Opción 1: Claude.ai (Proyectos)

1. Clona este repositorio:
   ```bash
   git clone https://github.com/tu-usuario/asesor-fiscal-mexico.git
   ```

2. En Claude.ai, crea un nuevo **Proyecto**

3. Sube los archivos al proyecto:
   - `SKILL.md` → instrucciones del proyecto
   - Carpeta `references/` → documentos de referencia
   - Tus propios documentos del SAT (PDF, DOCX)

4. En las instrucciones del proyecto, agrega:
   ```
   Usa la skill asesor-fiscal-mexico siguiendo el SKILL.md adjunto.
   ```

### Opción 2: Claude Code (Cowork)

```bash
# Instala la skill en tu directorio de skills
cp -r asesor-fiscal-mexico ~/.claude/skills/

# O instala el .skill file si está disponible
claude skill install asesor-fiscal-mexico.skill
```

---

## Cómo usar

### Análisis de régimen fiscal

```
"Tengo un negocio de venta de tamales con ventas de $30,000 semanales.
¿Qué régimen fiscal me recomiendas?"
```

### Excel de deducciones

```
"Genera un Excel con la propuesta de deducciones mensuales para mi régimen"
```

### Dashboard comparativo PF vs PM

```
"Compara si me conviene ser persona física o moral, considerando que
el 80% de mis ventas son en efectivo y tengo 6 empleados"
```

### Simulador de nómina

```
"¿Cuánto me cuesta tener un empleado con salario de $8,000 al mes
considerando IMSS, INFONAVIT y SAR?"
```

### Agregar repositorio propio

```
"Agrega este repositorio como fuente de referencia adicional:
https://github.com/mi-empresa/politicas-fiscales"
```

---

## Agregar tus propias fuentes

En `SKILL.md`, localiza la sección `## Integración con repositorios externos` y agrega tu repositorio:

```yaml
repositorios:
  - nombre: "Mis políticas fiscales"
    url: "https://github.com/mi-empresa/politicas-fiscales"
    tipo: "personalizado"
```

La skill usará `web_fetch` para leer el contenido y lo incorporará en sus análisis.

---

## Documentos de referencia incluidos

Basados en fuentes oficiales:

| Documento | Fuente |
|---|---|
| Guía de Regímenes Fiscales SAT | SAT México · Mayo 2026 |
| LISR (Ley del ISR) | Cámara de Diputados · diputados.gob.mx |
| Tablas de tasas RESICO | Art. 113-E LISR |
| Límites deducciones personales | Art. 151 LISR |

Para agregar tus propios documentos, colócalos en la carpeta `references/` en formato Markdown o súbelos directamente al Proyecto de Claude.

---

## Advertencia legal

> Esta skill proporciona información fiscal orientativa con fines educativos y de planeación preliminar. **No sustituye el análisis personalizado con un contador público certificado e inscrito ante el SAT.** Siempre consulta a un profesional antes de tomar decisiones fiscales.

---

## Contribuciones

¿Detectaste información desactualizada o quieres agregar un régimen? Abre un PR con:
1. La referencia normativa exacta (artículo + ley + DOF de publicación)
2. La fuente oficial (sat.gob.mx o diputados.gob.mx)
3. La fecha de vigencia del cambio

---

## Licencia

MIT — Libre para uso personal y comercial con atribución.
